
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JFrame;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/**
 *
 * @author USER
 */
public class Database_read_write 
{
    
    private FileInputStream fis;
    private FileOutputStream fos;
    private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    private int rowTotal,colTotal;
    private String form_type;
    private Temporary_database employee_data;
    private String pathname;
    
    public Database_read_write(String filename,int sheet_index,String type) throws FileNotFoundException, IOException
    {
        pathname = "database//"+filename;
        fis = new FileInputStream(new File(pathname));
        workbook = new XSSFWorkbook(fis);
        sheet = workbook.getSheetAt(sheet_index);
        rowTotal = sheet.getLastRowNum()+1;
        colTotal = sheet.getRow(0).getLastCellNum();
        form_type=type;
        employee_data= new Temporary_database(rowTotal,colTotal);
    }
    
    public Database_read_write(String filename,int sheet_index,String type,Temporary_database tb,int rows,int cols) throws FileNotFoundException, IOException
    {
        pathname = "database//"+filename;
        fis = new FileInputStream(new File(pathname));
        workbook = new XSSFWorkbook(fis);
        sheet = workbook.getSheetAt(sheet_index);
        rowTotal = rows;
        colTotal = cols;
        form_type=type;
        employee_data = tb;
    }   

    
    public Temporary_database read_it(JFrame parent_frame) throws Our_Exception
    {
        try
        {
            int irow=0;
            
            for(Row row : sheet) 
            {   
                String []s = new String [colTotal];
                int icol=0;
                for(Cell cell : row) 
                {
                    cell.setCellType(Cell.CELL_TYPE_STRING);

                    s[icol]=(String)cell.getStringCellValue();

                    if(s[icol]==null)
                    {
                        if(form_type.equals("register"))throw new Our_Exception("database_error",parent_frame);
                    }
                    icol++;
                }

                employee_data.Store(irow,s);
                irow++;
            }   
            System.out.println("writing from read_it(0)");
            System.out.println(employee_data.get_no_of_rows()+" "+employee_data.get_no_of_cols());
            employee_data.display();
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        try 
        {
            fis.close();
        } 
        catch (IOException ex) 
        {
            throw new Our_Exception("Errors",parent_frame);
        }
        
        System.out.println("writing from read_it");
        System.out.println(employee_data.get_no_of_rows()+" "+employee_data.get_no_of_cols());
        return employee_data;
    }
    
    
    
    public String[] read_it(JFrame parent_frame,String info) throws Our_Exception
    {
        try
        {
            int irow=0;
            
            for(Row row : sheet) 
            {   
                String []s = new String [colTotal];
                int icol=0;
                boolean flag = false;
                for(Cell cell : row) 
                {
                    cell.setCellType(Cell.CELL_TYPE_STRING);

                    s[icol]=(String)cell.getStringCellValue();

                    if(s[icol].length()==0)
                    {
                        if(form_type.equals("register"))throw new Our_Exception("database_error",parent_frame);
                    }
                    if(!s[icol].equals(info) && flag==false)break;
                    flag=true;
                    icol++;
                }
                if(flag)
                {
                    //employee_data.Store(0,s);
                    return s;
                }
            }   
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        try 
        {
            fis.close();
        } 
        catch (IOException ex) 
        {
            throw new Our_Exception("Errors",parent_frame);
        }
        String []s = new String [colTotal];
        return s;
    }
    
    public String[] read_employee(JFrame parent_frame,int x) throws Our_Exception
    {
        try
        {
            int irow=0;
            String []s = new String [rowTotal];
            for(Row row : sheet) 
            {   
                int icol=0;
                if(irow==0)
                {
                    irow++;
                    continue;
                }
                Cell cell = row.getCell(x);
                cell.setCellType(Cell.CELL_TYPE_STRING);
                if((String)cell.getStringCellValue()==null)continue;
                s[irow-1]=(String)cell.getStringCellValue();
                System.out.println(s[irow]+" "+irow);
                irow++;
            }   
            System.out.println("from read employee");
            for(String str:s)
            {
                System.out.println(str);
            }
            return s;
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        try 
        {
            fis.close();
        } 
        catch (IOException ex) 
        {
            throw new Our_Exception("Errors",parent_frame);
        }
        String []s = new String [colTotal];
        return s;
    }
    
    
    
    
    public void write_it(JFrame parent_frame) throws FileNotFoundException, IOException, Our_Exception
    {
        Row current_row = sheet.createRow(rowTotal);
        for(int i=0;i<colTotal;i++)
        {
            String value = employee_data.get_value_at(rowTotal, i);
            System.out.println("value = "+value+" "+rowTotal+" "+colTotal);
            if(value==null)continue;
            
            current_row.createCell(i).setCellValue(value);
        }
        try 
        {
            fis.close();
        } 
        catch (IOException ex) 
        {
            throw new Our_Exception("Errors",parent_frame);
        }
        fos = new FileOutputStream(new File(pathname));
        workbook.write(fos);
        fos.close();
        System.out.println("writing from write_it");
        System.out.println(employee_data.get_no_of_rows()+" "+employee_data.get_no_of_cols());
        employee_data.display();        
    }
    
    public void write_it_whole(JFrame parent_frame) throws FileNotFoundException, IOException, Our_Exception
    {
        int irow = 0;
        for(Row row : sheet) 
        {   
            int icol =0;
            
            for(Cell cell : row) 
            {
                cell.setCellValue(employee_data.get_value_at(irow, icol));
                
                cell.setCellType(Cell.CELL_TYPE_STRING);
                
                icol++;
            }
            irow++;
        }
        try 
        {
            fis.close();
        } 
        catch (IOException ex) 
        {
            throw new Our_Exception("Errors",parent_frame);
        }
        fos = new FileOutputStream(new File(pathname));
        workbook.write(fos);
        fos.close();
        System.out.println("writing from write_it");
        System.out.println(employee_data.get_no_of_rows()+" "+employee_data.get_no_of_cols());
        employee_data.display();        
    }
    
    
    public int get_rowTotal()
    {
        return rowTotal;
    }
    public int get_colTotal()
    {
        return colTotal;
    }
    
}
