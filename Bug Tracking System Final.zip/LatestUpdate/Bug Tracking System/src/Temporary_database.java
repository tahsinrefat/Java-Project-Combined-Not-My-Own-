/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class Temporary_database
{
    private String [][] str ;
    private int rows,cols;
    Temporary_database(int i,int j)
    {
        rows=i;
        cols=j;
        str = new String [rows+10][cols+10];
    }
    public void Store(int index, String [] s)
    {
        for (int i = 0; i < cols; i++) 
        {
            if(s[i]==null)continue;
            s[i]=s[i].toLowerCase();
            str[index][i] = s[i];
        }
        //rows++;
    }
    public void set_row(int i)
    {
        rows=i;
    }
    public void set_col(int i)
    {
        cols=i;
    }
    
    public String get_value_at(int i,int j)
    {
        return str[i][j];
    }
    public void set_value_at(int i,int j,String s)
    {
        str[i][j]=s;
    }
    
    public int get_no_of_rows()
    {
        return rows;
    }
    public int get_no_of_cols()
    {
        return cols;
    }
    
    public boolean if_match(String [] s)
    {
        for (int index = 1; index < rows; index++) 
        {
            int i=0;
            for(   ; i < cols; i++) 
            {
                if(s[i]==null)break; 
                if(str[index][i]==null) continue;
                if(!(str[index][i].equals(s[i])))break;
            }
            if(i==cols)return true;
        }
        return false;
    }
    
    public void display()
    {
        
        for (int index = 0; index < rows; index++) 
        {
            for (int i=0  ; i < cols; i++) 
            {
                //if(str[index][i]==null)continue;
                System.out.print(str[index][i]+ " ");
            }
            System.out.println("");
        }
        
    }
        
}


