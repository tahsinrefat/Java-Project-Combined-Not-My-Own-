
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class ManagerHomePage extends javax.swing.JFrame {
    
    DefaultTableModel ptable;
    String man_id;
    public ManagerHomePage(String x) throws Our_Exception 
    {
        
        initComponents();
        this.setLocationRelativeTo(null);
        
        welcomeTxt.setText("Welcome "+x);
        man_id=x;
        
        this.ptable = (DefaultTableModel)jTable1.getModel();
        
        Database_read_write reading_proj_file = null;     
        try 
        {
            reading_proj_file = new Database_read_write("our_main_data.xlsx",3,"getproject");
        } 
        catch (IOException ex) 
        {
            throw new Our_Exception("Errors",this);
            //Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
            //return;
        }
        String []str  = reading_proj_file.read_employee(this,0);
        
        int cnt = 0;
        for(String st:str)
        {
            
            Vector<String>vs = new Vector();
            if(st.equals("_null_"))continue;
            vs.add(st);
            cnt++;
            ptable.addRow(vs);
            System.out.println(st);
        }
        jTable1.getColumnModel().getColumn(0).setHeaderValue("Total Number of active projects : " + Integer.toString(cnt) );
        
        
        
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole = new javax.swing.JPanel();
        welcomeTxt = new javax.swing.JLabel();
        addNewProjectBtn = new javax.swing.JButton();
        editProjectBtn = new javax.swing.JButton();
        addNewProjectBtn1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bgdPic = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Welcome to Bug Tracking System");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(0, 0));
        setName("Whole"); // NOI18N
        setResizable(false);
        setType(java.awt.Window.Type.UTILITY);

        whole.setLayout(null);

        welcomeTxt.setFont(new java.awt.Font("Sitka Subheading", 1, 36)); // NOI18N
        welcomeTxt.setForeground(new java.awt.Color(255, 255, 255));
        welcomeTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        welcomeTxt.setText("Name");
        whole.add(welcomeTxt);
        welcomeTxt.setBounds(10, 10, 320, 80);

        addNewProjectBtn.setBackground(new java.awt.Color(0, 0, 0));
        addNewProjectBtn.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        addNewProjectBtn.setForeground(new java.awt.Color(255, 255, 255));
        addNewProjectBtn.setText("Add New Project");
        addNewProjectBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNewProjectBtnActionPerformed(evt);
            }
        });
        whole.add(addNewProjectBtn);
        addNewProjectBtn.setBounds(320, 300, 290, 30);

        editProjectBtn.setBackground(new java.awt.Color(0, 0, 0));
        editProjectBtn.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        editProjectBtn.setForeground(new java.awt.Color(255, 255, 255));
        editProjectBtn.setText("Edit Project");
        editProjectBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editProjectBtnActionPerformed(evt);
            }
        });
        whole.add(editProjectBtn);
        editProjectBtn.setBounds(320, 360, 290, 30);

        addNewProjectBtn1.setBackground(new java.awt.Color(255, 0, 0));
        addNewProjectBtn1.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        addNewProjectBtn1.setForeground(new java.awt.Color(255, 255, 255));
        addNewProjectBtn1.setText("Log Out");
        addNewProjectBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNewProjectBtn1ActionPerformed(evt);
            }
        });
        whole.add(addNewProjectBtn1);
        addNewProjectBtn1.setBounds(740, 20, 140, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No Ongoing Projects"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
        }

        whole.add(jScrollPane1);
        jScrollPane1.setBounds(240, 80, 452, 190);

        bgdPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bugbgd.jpg"))); // NOI18N
        whole.add(bgdPic);
        bgdPic.setBounds(0, 0, 890, 450);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole, javax.swing.GroupLayout.DEFAULT_SIZE, 890, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addNewProjectBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNewProjectBtnActionPerformed
        this.setVisible(false);
        try {
            new AddNewProject(man_id).setVisible(true);
        } catch (IOException ex) {
            //Logger.getLogger(ManagerHomePage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Our_Exception ex) {
            //Logger.getLogger(ManagerHomePage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addNewProjectBtnActionPerformed

    private void editProjectBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editProjectBtnActionPerformed
        this.setVisible(false);
        try {
            new EditProject(man_id).setVisible(true);
        } catch (Our_Exception ex) {
            //Logger.getLogger(ManagerHomePage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            //Logger.getLogger(ManagerHomePage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_editProjectBtnActionPerformed

    private void addNewProjectBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNewProjectBtn1ActionPerformed
        this.setVisible(false);
        new login().setVisible(true);
    }//GEN-LAST:event_addNewProjectBtn1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagerHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagerHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagerHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagerHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new ManagerHomePage("abc").setVisible(true);
                } catch (Our_Exception ex) {
                    Logger.getLogger(ManagerHomePage.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addNewProjectBtn;
    private javax.swing.JButton addNewProjectBtn1;
    private javax.swing.JLabel bgdPic;
    private javax.swing.JButton editProjectBtn;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel welcomeTxt;
    private javax.swing.JPanel whole;
    // End of variables declaration//GEN-END:variables
}
