
import java.io.IOException;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class HomeEmployee extends javax.swing.JFrame {
    
    public String info,name;
    Vector<String> code,test;  
    String[] my_data;
    DefaultTableModel ctable;
    DefaultTableModel ttable;
    HashMap<String, Integer> index = new HashMap<String, Integer>();
    HashMap<String, Integer> cindex = new HashMap<String, Integer>();
    HashMap<String, Integer> pindex = new HashMap<String, Integer>();
    HashMap<String, Integer> tindex = new HashMap<String, Integer>();
    Temporary_database proj_data;
    
    public HomeEmployee(String s) throws IOException, Our_Exception 
    {
        
        initComponents();
        this.ttable = (DefaultTableModel)testproj.getModel();
        this.ctable = (DefaultTableModel)assignedproj.getModel();
        this.setLocationRelativeTo(null);
        
        info = s;
        System.out.println("just openned "+info);
        code=new Vector<String>();
        test=new Vector<String>();
        
        load();
        
        welcometxt.setText("Welcome "+name); 
    }
    void load() throws IOException, Our_Exception
    {
        Database_read_write reading_file = new Database_read_write("our_main_data.xlsx",0,"homeemployee");
        my_data=reading_file.read_it(this,info);
        name = my_data[2];
        
        String proj = my_data[6];
        
        for (String str: proj.split(",")) 
        {
            System.out.println(str);
            if(str.charAt(0)=='>')code.add(str.substring(1));
            else if(str.charAt(0)=='<')test.add(str.substring(1));
        }
        
        reading_file = new Database_read_write("our_main_data.xlsx",3,"updateproj");        
        proj_data = reading_file.read_it(this);
        
        
        for(int i=1;i<proj_data.get_no_of_rows();i++)
        {
            System.out.println("values init: "+ proj_data.get_value_at(i, 0)+" = "+i);
            cindex.put(proj_data.get_value_at(i, 0),i);
        }
        
        System.out.println("codes---");
        assignedproj.getColumnModel().getColumn(0).setHeaderValue("Total Number of active projects assigned for you : " + Integer.toString(code.size()) );
        for(String str : code)
        {
            Vector<String>vs = new Vector();
            vs.add(str);
            ctable.addRow(vs);
            pindex.put(str,cindex.get(str));
            System.out.println(str);
        }
        System.out.println("tests---");
        testproj.getColumnModel().getColumn(0).setHeaderValue("Total Number of active projects for testing : " + Integer.toString(test.size()) );
        for(String str : test)
        {
            Vector<String>vs = new Vector();
            vs.add(str);
            ttable.addRow(vs);
            tindex.put(str,cindex.get(str));
            System.out.println(str);
        }    
        
        
        
        
        
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole = new javax.swing.JPanel();
        testprojtxt = new javax.swing.JLabel();
        welcometxt = new javax.swing.JLabel();
        assproj = new javax.swing.JLabel();
        testtable = new javax.swing.JScrollPane();
        testproj = new javax.swing.JTable();
        codetable = new javax.swing.JScrollPane();
        assignedproj = new javax.swing.JTable();
        logout = new javax.swing.JButton();
        assproj1 = new javax.swing.JLabel();
        assproj2 = new javax.swing.JLabel();
        assproj3 = new javax.swing.JLabel();
        gotoprojtext = new javax.swing.JTextField();
        bugsolveprojectnametext = new javax.swing.JTextField();
        bugslvtxt = new javax.swing.JTextField();
        slvbtn = new javax.swing.JButton();
        enterbtn = new javax.swing.JButton();
        assproj4 = new javax.swing.JLabel();
        assproj5 = new javax.swing.JLabel();
        assproj6 = new javax.swing.JLabel();
        bugreportprojectnametxt = new javax.swing.JTextField();
        assproj7 = new javax.swing.JLabel();
        bugreporttxt = new javax.swing.JTextField();
        bugbtn1 = new javax.swing.JButton();
        bgdPic = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Welcome Employee");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(0, 0));
        setName("Whole"); // NOI18N
        setResizable(false);
        setType(java.awt.Window.Type.UTILITY);

        whole.setLayout(null);

        testprojtxt.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        testprojtxt.setForeground(new java.awt.Color(255, 255, 255));
        testprojtxt.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        testprojtxt.setText("Projects for testing:");
        whole.add(testprojtxt);
        testprojtxt.setBounds(580, 60, 300, 60);

        welcometxt.setFont(new java.awt.Font("Sitka Subheading", 1, 36)); // NOI18N
        welcometxt.setForeground(new java.awt.Color(255, 255, 255));
        welcometxt.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        welcometxt.setText("Name");
        whole.add(welcometxt);
        welcometxt.setBounds(10, 20, 460, 50);

        assproj.setFont(new java.awt.Font("Sitka Subheading", 1, 20)); // NOI18N
        assproj.setForeground(new java.awt.Color(255, 255, 255));
        assproj.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        assproj.setText("Report a Bug :");
        whole.add(assproj);
        assproj.setBounds(530, 320, 140, 30);

        testproj.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        testproj.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No projects yet!"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        testtable.setViewportView(testproj);
        if (testproj.getColumnModel().getColumnCount() > 0) {
            testproj.getColumnModel().getColumn(0).setResizable(false);
        }

        whole.add(testtable);
        testtable.setBounds(580, 110, 260, 180);

        assignedproj.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        assignedproj.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No Projects Yet!"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        assignedproj.setShowGrid(false);
        assignedproj.setShowVerticalLines(true);
        codetable.setViewportView(assignedproj);
        if (assignedproj.getColumnModel().getColumnCount() > 0) {
            assignedproj.getColumnModel().getColumn(0).setResizable(false);
        }

        whole.add(codetable);
        codetable.setBounds(50, 110, 250, 190);

        logout.setBackground(new java.awt.Color(255, 0, 0));
        logout.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        logout.setForeground(new java.awt.Color(255, 255, 255));
        logout.setText("LogOut");
        whole.add(logout);
        logout.setBounds(780, 30, 73, 23);

        assproj1.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        assproj1.setForeground(new java.awt.Color(255, 255, 255));
        assproj1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        assproj1.setText("Your Assigned Projects :");
        whole.add(assproj1);
        assproj1.setBounds(50, 60, 300, 60);

        assproj2.setFont(new java.awt.Font("Sitka Subheading", 1, 20)); // NOI18N
        assproj2.setForeground(new java.awt.Color(255, 255, 255));
        assproj2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        assproj2.setText("Go to project :");
        whole.add(assproj2);
        assproj2.setBounds(370, 170, 140, 30);

        assproj3.setFont(new java.awt.Font("Sitka Subheading", 1, 20)); // NOI18N
        assproj3.setForeground(new java.awt.Color(255, 255, 255));
        assproj3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        assproj3.setText("Bug Name :");
        whole.add(assproj3);
        assproj3.setBounds(10, 390, 110, 30);
        whole.add(gotoprojtext);
        gotoprojtext.setBounds(360, 200, 170, 20);

        bugsolveprojectnametext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bugsolveprojectnametextActionPerformed(evt);
            }
        });
        whole.add(bugsolveprojectnametext);
        bugsolveprojectnametext.setBounds(160, 360, 150, 20);
        whole.add(bugslvtxt);
        bugslvtxt.setBounds(130, 390, 180, 20);

        slvbtn.setText("submit");
        slvbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                slvbtnActionPerformed(evt);
            }
        });
        whole.add(slvbtn);
        slvbtn.setBounds(320, 370, 80, 23);

        enterbtn.setText("GO");
        enterbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enterbtnActionPerformed(evt);
            }
        });
        whole.add(enterbtn);
        enterbtn.setBounds(420, 230, 50, 23);

        assproj4.setFont(new java.awt.Font("Sitka Subheading", 1, 20)); // NOI18N
        assproj4.setForeground(new java.awt.Color(255, 255, 255));
        assproj4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        assproj4.setText("Report Bug Solved:");
        whole.add(assproj4);
        assproj4.setBounds(10, 320, 180, 30);

        assproj5.setFont(new java.awt.Font("Sitka Subheading", 1, 20)); // NOI18N
        assproj5.setForeground(new java.awt.Color(255, 255, 255));
        assproj5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        assproj5.setText("Project Name :");
        whole.add(assproj5);
        assproj5.setBounds(10, 360, 140, 30);

        assproj6.setFont(new java.awt.Font("Sitka Subheading", 1, 20)); // NOI18N
        assproj6.setForeground(new java.awt.Color(255, 255, 255));
        assproj6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        assproj6.setText("Project Name :");
        whole.add(assproj6);
        assproj6.setBounds(530, 360, 140, 30);

        bugreportprojectnametxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bugreportprojectnametxtActionPerformed(evt);
            }
        });
        whole.add(bugreportprojectnametxt);
        bugreportprojectnametxt.setBounds(670, 360, 110, 20);

        assproj7.setFont(new java.awt.Font("Sitka Subheading", 1, 20)); // NOI18N
        assproj7.setForeground(new java.awt.Color(255, 255, 255));
        assproj7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        assproj7.setText("Bug Name :");
        whole.add(assproj7);
        assproj7.setBounds(530, 390, 110, 30);
        whole.add(bugreporttxt);
        bugreporttxt.setBounds(650, 390, 130, 20);

        bugbtn1.setText("submit");
        bugbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bugbtn1ActionPerformed(evt);
            }
        });
        whole.add(bugbtn1);
        bugbtn1.setBounds(790, 380, 80, 23);

        bgdPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bugbgd.jpg"))); // NOI18N
        whole.add(bgdPic);
        bgdPic.setBounds(0, 0, 890, 450);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole, javax.swing.GroupLayout.PREFERRED_SIZE, 890, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void bugsolveprojectnametextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bugsolveprojectnametextActionPerformed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_bugsolveprojectnametextActionPerformed

    private void enterbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enterbtnActionPerformed
        // TODO add your handling code here:
        
        String id , bug;
        try
        {
            boolean flag = true;
            id = gotoprojtext.getText();
            id.toLowerCase();
            if(id==null)
            {
                flag = false;
                throw new Our_Exception("something null",this);
            }
            if(tindex.get(id)==null && pindex.get(id)==null)
            {
                flag = false;
                throw new Our_Exception("projnotfound",this);
            }
            
            if(flag == true)
            {
                this.setVisible(false);
       
                try {
                    ProjectsOverView lrg = new ProjectsOverView(info,id,"employee");
                    lrg.setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(ProjectsOverView.class.getName()).log(Level.SEVERE, null, ex);
                } catch (Our_Exception ex) {
                    Logger.getLogger(ProjectsOverView.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        catch(Exception ex)
        {
            id = bugreportprojectnametxt.getText();
            id.toLowerCase();
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }//GEN-LAST:event_enterbtnActionPerformed

    private void bugreportprojectnametxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bugreportprojectnametxtActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_bugreportprojectnametxtActionPerformed

    private void bugbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bugbtn1ActionPerformed
        // TODO add your handling code here:
        String id , bug;
        try
        {
            boolean flag = true;
            id = bugreportprojectnametxt.getText();
            id.toLowerCase();
            bug= bugreporttxt.getText();
            bug.toLowerCase();
            if(id==null || bug==null)
            {
                flag = false;
                throw new Our_Exception("something null",this);
            }
            if(tindex.get(id)==null)
            {
                flag = false;
                throw new Our_Exception("projnotfound",this);
            }
            
            if(flag == true)
            {
                int idx = tindex.get(id);
                String old = proj_data.get_value_at(idx, 3);
                System.out.println("added old --------------------------------->"+old);
                
                System.out.println("old before = "+old);
                
                if(old.equals("_null_"))
                {
                    old = bug;
                }
                else
                {
                    old+=(","+bug);
                }
                
                System.out.println("old now = "+old);
                
                proj_data.set_value_at(idx, 3,old);
                System.out.println("added new --------------------------------->"+old);
                
                Database_read_write writing_proj_file = null ;   

                try 
                {
                    writing_proj_file = new Database_read_write("our_main_data.xlsx",3,"bugadded",proj_data,proj_data.get_no_of_rows(),proj_data.get_no_of_cols());
                }
                catch (IOException ex) 
                {
                    flag = false;
                    throw new Our_Exception("Errors",this);
                    //Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                }
                try 
                {
                    flag = false;
                    writing_proj_file.write_it_whole( this);
                }
                catch (IOException ex) 
                {
                    flag = false;
                    throw new Our_Exception("Errors",this);
                    //Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                JOptionPane.showMessageDialog(this, "Bug Reported!", "Operation Successfull!", JOptionPane.INFORMATION_MESSAGE);
                
            }
        }
        catch(Exception ex)
        {
            id = bugreportprojectnametxt.getText();
            id.toLowerCase();
            bug= bugreporttxt.getText();
            bug.toLowerCase();
        }
    }//GEN-LAST:event_bugbtn1ActionPerformed

    private void slvbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_slvbtnActionPerformed
        // TODO add your handling code here:
        String id , bug;
        try
        {
            boolean flag = true;
            id = bugsolveprojectnametext.getText();
            id.toLowerCase();
            bug= bugslvtxt.getText();
            bug.toLowerCase();
            if(id==null || bug==null)
            {
                flag = false;
                throw new Our_Exception("emptydata",this);
            }
            if(pindex.get(id)==null)
            {
                flag = false;
                throw new Our_Exception(id+" idDoesntexist",this);
            }
            boolean fg2=false;
            String cbugs = proj_data.get_value_at(pindex.get(id), 3);
            if(!cbugs.equals("_null_"))
            {
                for(String str: cbugs.split(",")) 
                {
                    if(str.equals(bug))
                    {
                        fg2 = true;
                        break;
                    }
                }
            }
            if(!fg2)
            {
                flag = false;
                throw new Our_Exception("bugDoesntExist",this);
            }

            if(flag == true)
            {
                int idx = pindex.get(id);
                String old = proj_data.get_value_at(idx, 3);
                System.out.println("removed old --------------------------------->"+old);

                Vector<String>vs=new Vector<String>();
                for(String st : old.split(","))
                {
                    vs.add(st);
                }
                vs.remove(bug);
                if(vs.size()==0)
                {
                    old= "_null_";
                }
                else
                {
                    old="";
                    for(String st:vs)
                    {
                        old+=(st+",");
                    }
                    old = old.substring(0, old.length() - 1);
                }
                proj_data.set_value_at(idx, 3,old);
                System.out.println("removed new --------------------------------->"+old);
                
                
                
                Database_read_write writing_proj_file = null ;   

                try 
                {
                    writing_proj_file = new Database_read_write("our_main_data.xlsx",3,"bugremoved",proj_data,proj_data.get_no_of_rows(),proj_data.get_no_of_cols());
                }
                catch (IOException ex) 
                {
                    flag = false;
                    throw new Our_Exception("Errors",this);
                    //Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                }
                try 
                {
                    flag = false;
                    writing_proj_file.write_it_whole( this);
                }
                catch (IOException ex) 
                {
                    flag = false;
                    throw new Our_Exception("Errors",this);
                    //Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                JOptionPane.showMessageDialog(this, "Bug Resolved!", "Operation Successfull!", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        catch(Exception ex)
        {
            id = bugsolveprojectnametext.getText();
            id.toLowerCase();
            bug= bugslvtxt.getText();
            bug.toLowerCase();
        }
    }//GEN-LAST:event_slvbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                try {
                    try {
                        new HomeEmployee("abc").setVisible(true);
                    } catch (Our_Exception ex) {
                        Logger.getLogger(HomeEmployee.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } catch (IOException ex) {
                    Logger.getLogger(HomeEmployee.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable assignedproj;
    private javax.swing.JLabel assproj;
    private javax.swing.JLabel assproj1;
    private javax.swing.JLabel assproj2;
    private javax.swing.JLabel assproj3;
    private javax.swing.JLabel assproj4;
    private javax.swing.JLabel assproj5;
    private javax.swing.JLabel assproj6;
    private javax.swing.JLabel assproj7;
    private javax.swing.JLabel bgdPic;
    private javax.swing.JButton bugbtn1;
    private javax.swing.JTextField bugreportprojectnametxt;
    private javax.swing.JTextField bugreporttxt;
    private javax.swing.JTextField bugslvtxt;
    private javax.swing.JTextField bugsolveprojectnametext;
    private javax.swing.JScrollPane codetable;
    private javax.swing.JButton enterbtn;
    private javax.swing.JTextField gotoprojtext;
    private javax.swing.JButton logout;
    private javax.swing.JButton slvbtn;
    private javax.swing.JTable testproj;
    private javax.swing.JLabel testprojtxt;
    private javax.swing.JScrollPane testtable;
    private javax.swing.JLabel welcometxt;
    private javax.swing.JPanel whole;
    // End of variables declaration//GEN-END:variables
}
