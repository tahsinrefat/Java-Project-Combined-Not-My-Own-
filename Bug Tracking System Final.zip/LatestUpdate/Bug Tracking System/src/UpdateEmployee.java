
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class UpdateEmployee {
    
    Temporary_database employee_data;
    JFrame parent_frame;
    HashMap<String, Integer> index = new HashMap<String, Integer>();
    
    public UpdateEmployee(JFrame pf) throws IOException, Our_Exception
    {
        Database_read_write reading_file = new Database_read_write("our_main_data.xlsx",0,"updateemployee");        
        employee_data = reading_file.read_it(pf);
        parent_frame = pf;
        for(int i=1;i<employee_data.get_no_of_rows();i++)index.put(employee_data.get_value_at(i, 1),i);
    }
    
    public void add(String id,String proj,String type)
    {
        int idx = index.get(id);
        String old = employee_data.get_value_at(idx, 6);
        System.out.println("added old --------------------------------->"+old);
        String sign;
        if(type.equals("tester"))sign="<";
        else sign = ">";
        proj = sign+proj;
        if(old.equals("_null_"))
        {
            System.out.println("yoooooooooooooooooooooooooooooooooooooooo");
            old=proj;
            employee_data.set_value_at(idx, 6,proj);
        }
        else
        {
            old=old+","+proj;
            employee_data.set_value_at(idx, 6,old);
        }
        System.out.println("added new --------------------------------->"+old);
    }
    public void remove(String id,String proj,String type)
    {
        int idx = index.get(id);
        String old = employee_data.get_value_at(idx, 6);
        System.out.println("removed old --------------------------------->"+old);
        String sign;
        if(type.equals("tester"))sign="<";
        else sign = ">";
        proj = sign+proj;
        Vector<String>vs=new Vector<String>();
        for(String st : old.split(","))
        {
            vs.add(st);
        }
        vs.remove(proj);
        if(vs.size()==0)
        {
            old= "_null_";
        }
        else
        {
            old="";
            for(String st:vs)
            {
                old+=(st+",");
            }
            old = old.substring(0, old.length() - 1);
        }
        employee_data.set_value_at(idx, 6,old);
        System.out.println("removed new --------------------------------->"+old);
    }
    public void finish() throws FileNotFoundException, Our_Exception
    {
        Database_read_write writing_employee_file = null ;   
            
        try 
        {
            writing_employee_file = new Database_read_write("our_main_data.xlsx",0,"updateemployee",employee_data,employee_data.get_no_of_rows(),employee_data.get_no_of_cols());
        }
        catch (IOException ex) 
        {
            throw new Our_Exception("Errors",parent_frame);
            //Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        }
        try 
        {
            writing_employee_file.write_it_whole( parent_frame);
        }
        catch (IOException ex) 
        {
            throw new Our_Exception("Errors",parent_frame);
            //Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


