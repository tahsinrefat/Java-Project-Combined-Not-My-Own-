
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class Our_Exception extends Exception 
{
    public Our_Exception(String st,JFrame reg) 
    {
        if(st.equals("database_error"))
        {
            JOptionPane.showMessageDialog(reg, "Your Employee Database lacks some Information!", "Database incomplete!", JOptionPane.ERROR_MESSAGE);
            
        }
        if(st.equals("didnt_match"))
        {
            JOptionPane.showMessageDialog(reg, "Records Didn't Match!", "Mismatch!", JOptionPane.ERROR_MESSAGE);

        }
        if(st.equals("invalid_email"))
        {
            JOptionPane.showMessageDialog(reg, "Your Email ID is invalid,check for spelling errors!", "Email Mismatch!", JOptionPane.ERROR_MESSAGE);

        }
        if(st.equals("invalid_pass"))
        {
            JOptionPane.showMessageDialog(reg, "Your Password Didn't Meet the Minimum Requirements!", "Weak Password!", JOptionPane.ERROR_MESSAGE);

        }
        if(st.equals("pass_con_failed"))
        {
            JOptionPane.showMessageDialog(reg, "Passwords Didn't Match!", "Confirmation Error!", JOptionPane.ERROR_MESSAGE);
        }
        // id_pass_didnt_match
        if(st.equals("account_already_exits"))
        {
            JOptionPane.showMessageDialog(reg, "Account already exits either with ID or Gmail!", "Account Exists!", JOptionPane.ERROR_MESSAGE);
        }
        if(st.equals("null_id"))
        {
            JOptionPane.showMessageDialog(reg, "Please fillup both fields!", "Input Error!", JOptionPane.ERROR_MESSAGE);
        }
        if(st.equals("id_pass_didnt_match"))
        {
            JOptionPane.showMessageDialog(reg, "ID ,Password didn't match!", "Login Unsucessful!", JOptionPane.ERROR_MESSAGE);
        }
        if(st.equals("Errors"))
        {
            JOptionPane.showMessageDialog(reg, "Operation Unsuccesful !", "ERROR!", JOptionPane.ERROR_MESSAGE);
        }
        else 
        {
            JOptionPane.showMessageDialog(reg, st, "ERROR!", JOptionPane.ERROR_MESSAGE);
        }
    }
}
