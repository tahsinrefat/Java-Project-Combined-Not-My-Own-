public class HomePage extends javax.swing.JFrame {
    public HomePage() 
    {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole = new javax.swing.JPanel();
        welcomeTxt = new javax.swing.JLabel();
        getStarted = new javax.swing.JButton();
        bgdPic = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Welcome to Bug Tracking System");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(0, 0));
        setName("Whole"); // NOI18N
        setResizable(false);
        setType(java.awt.Window.Type.UTILITY);

        whole.setLayout(null);

        welcomeTxt.setFont(new java.awt.Font("Sitka Subheading", 1, 36)); // NOI18N
        welcomeTxt.setForeground(new java.awt.Color(255, 255, 255));
        welcomeTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        welcomeTxt.setText("Welcome");
        whole.add(welcomeTxt);
        welcomeTxt.setBounds(280, 90, 320, 80);

        getStarted.setBackground(new java.awt.Color(0, 0, 0));
        getStarted.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        getStarted.setForeground(new java.awt.Color(255, 255, 255));
        getStarted.setText("Get Started!");
        getStarted.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getStartedActionPerformed(evt);
            }
        });
        whole.add(getStarted);
        getStarted.setBounds(240, 270, 420, 70);

        bgdPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bugbgd.jpg"))); // NOI18N
        whole.add(bgdPic);
        bgdPic.setBounds(0, 0, 890, 450);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole, javax.swing.GroupLayout.DEFAULT_SIZE, 890, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void getStartedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getStartedActionPerformed
        loginReg lr = new loginReg();
        lr.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_getStartedActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bgdPic;
    private javax.swing.JButton getStarted;
    private javax.swing.JLabel welcomeTxt;
    private javax.swing.JPanel whole;
    // End of variables declaration//GEN-END:variables
}
